import { products as productData, categories as categoryData } from "@/lib/product-data"
import { initializeLocalStorage } from "./local-storage-db"
export { initializeLocalStorage }
import { sql } from "./db"
import type { Product, Category } from "./product-data"
import type { CartItem } from "@/context/cart-context"

// Check if database is initialized
export async function isDatabaseInitialized() {
  try {
    // Check if categories table exists
    const result = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public'
        AND table_name = 'categories'
      );
    `
    return result[0]?.exists || false
  } catch (error) {
    console.error("Error checking database initialization:", error)
    return false
  }
}

// Products
export async function fetchProducts(limitCount = 20) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      ORDER BY created_at DESC
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching products:", error)
    return []
  }
}

export async function fetchProductById(productId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      const product = productData.find((p) => p.id === productId)
      return product || null
    }

    const [product] = await sql`
      SELECT * FROM products
      WHERE id = ${Number.parseInt(productId)}
    `

    if (!product) return null

    return formatProduct(product)
  } catch (error) {
    console.error("Error fetching product:", error)
    throw error
  }
}

export async function fetchProductsByCategory(categoryId: string, limitCount = 20) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.filter((p) => p.category === categoryId).slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      WHERE category_id = ${Number.parseInt(categoryId)}
      ORDER BY created_at DESC
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching products by category:", error)
    throw error
  }
}

export async function fetchFeaturedProducts(limitCount = 4) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.filter((p) => p.featured).slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      WHERE featured = TRUE
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching featured products:", error)
    throw error
  }
}

export async function fetchNewProducts(limitCount = 8) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.filter((p) => p.isNew).slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      WHERE is_new = TRUE
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching new products:", error)
    throw error
  }
}

export async function fetchSaleProducts(limitCount = 8) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.filter((p) => p.isOnSale).slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      WHERE is_on_sale = TRUE
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching sale products:", error)
    throw error
  }
}

export async function searchProducts(searchTerm: string, limitCount = 20) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData
        .filter(
          (p) =>
            p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
            p.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
            (p.tags && p.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase()))),
        )
        .slice(0, limitCount)
    }

    const dbProducts = await sql`
      SELECT * FROM products
      WHERE 
        name ILIKE ${`%${searchTerm}%`} OR
        description ILIKE ${`%${searchTerm}%`} OR
        tags::text ILIKE ${`%${searchTerm}%`}
      LIMIT ${limitCount}
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error searching products:", error)
    throw error
  }
}

// Add this function to fetch new arrivals

export async function getNewArrivals(limit = 8) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return productData.filter((p) => p.isNew).slice(0, limit)
    }

    const products = await sql`
      SELECT * FROM products
      ORDER BY created_at DESC
      LIMIT ${limit}
    `

    return products.map(formatProduct)
  } catch (error) {
    console.error("Error fetching new arrivals:", error)
    return []
  }
}

// Categories
export async function fetchCategories() {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      return categoryData
    }

    const dbCategories = await sql`SELECT * FROM categories`

    return dbCategories.map(formatCategory)
  } catch (error) {
    console.error("Error fetching categories:", error)
    throw error
  }
}

export async function fetchCategoryById(categoryId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, using local data")
      const category = categoryData.find((c) => c.id === categoryId)
      return category || null
    }

    const [category] = await sql`
      SELECT * FROM categories
      WHERE id = ${Number.parseInt(categoryId)}
    `

    if (!category) return null

    return formatCategory(category)
  } catch (error) {
    console.error("Error fetching category:", error)
    throw error
  }
}

// Orders
export interface Order {
  id?: string
  userId: string
  items: CartItem[]
  subtotal: number
  tax: number
  shipping: number
  total: number
  status: "pending" | "processing" | "shipped" | "delivered" | "cancelled"
  paymentMethod: string
  shippingAddress: {
    name: string
    address: string
    city: string
    state: string
    zipCode: string
    phone: string
  }
  createdAt?: any
  updatedAt?: any
}

export async function createOrder(orderData: Omit<Order, "id" | "createdAt" | "updatedAt">) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Check if user exists
    const [user] = await sql`SELECT * FROM users WHERE uid = ${orderData.userId}`
    if (!user) {
      throw new Error("User not found")
    }

    const [order] = await sql`
      INSERT INTO orders (
        user_id, items, subtotal, tax, shipping, total, status, payment_method, shipping_address
      ) VALUES (
        ${orderData.userId},
        ${JSON.stringify(orderData.items)},
        ${Math.round(orderData.subtotal * 100)},
        ${Math.round(orderData.tax * 100)},
        ${Math.round(orderData.shipping * 100)},
        ${Math.round(orderData.total * 100)},
        ${orderData.status}::order_status,
        ${orderData.paymentMethod},
        ${JSON.stringify(orderData.shippingAddress)}
      )
      RETURNING *
    `

    return formatOrder(order)
  } catch (error) {
    console.error("Error creating order:", error)
    throw error
  }
}

export async function fetchOrdersByUser(userId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning empty orders")
      return []
    }

    const orders = await sql`
      SELECT * FROM orders
      WHERE user_id = ${userId}
      ORDER BY created_at DESC
    `

    return orders.map(formatOrder)
  } catch (error) {
    console.error("Error fetching user orders:", error)
    throw error
  }
}

export async function fetchOrderById(orderId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning null order")
      return null
    }

    const [order] = await sql`
      SELECT * FROM orders
      WHERE id = ${Number.parseInt(orderId)}
    `

    if (!order) return null

    return formatOrder(order)
  } catch (error) {
    console.error("Error fetching order:", error)
    throw error
  }
}

export async function updateOrderStatus(orderId: string, status: Order["status"]) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    await sql`
      UPDATE orders
      SET status = ${status}::order_status, updated_at = NOW()
      WHERE id = ${Number.parseInt(orderId)}
    `

    return true
  } catch (error) {
    console.error("Error updating order status:", error)
    throw error
  }
}

// User profiles
export interface UserProfile {
  id?: string
  userId: string
  firstName: string
  lastName: string
  email: string
  phone?: string
  addresses?: {
    id: string
    name: string
    address: string
    city: string
    state: string
    zipCode: string
    isDefault: boolean
  }[]
  wishlist?: string[]
  createdAt?: any
  updatedAt?: any
}

export async function createUserProfile(userData: Omit<UserProfile, "id" | "createdAt" | "updatedAt">) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Check if user exists in users table
    const [existingUser] = await sql`SELECT * FROM users WHERE uid = ${userData.userId}`

    if (!existingUser) {
      // Create user if not exists
      await sql`
        INSERT INTO users (uid, email, display_name)
        VALUES (
          ${userData.userId},
          ${userData.email},
          ${`${userData.firstName} ${userData.lastName}`}
        )
      `
    }

    // Check if profile already exists
    const [existingProfile] = await sql`
      SELECT * FROM user_profiles
      WHERE user_id = ${userData.userId}
    `

    if (existingProfile) {
      // Update existing profile
      await sql`
        UPDATE user_profiles
        SET 
          first_name = ${userData.firstName},
          last_name = ${userData.lastName},
          email = ${userData.email},
          phone = ${userData.phone || null},
          addresses = ${userData.addresses ? JSON.stringify(userData.addresses) : null},
          wishlist = ${userData.wishlist ? JSON.stringify(userData.wishlist) : null},
          updated_at = NOW()
        WHERE user_id = ${userData.userId}
      `

      return fetchUserProfile(userData.userId)
    } else {
      // Create new profile
      const [profile] = await sql`
        INSERT INTO user_profiles (
          user_id, first_name, last_name, email, phone, addresses, wishlist
        ) VALUES (
          ${userData.userId},
          ${userData.firstName},
          ${userData.lastName},
          ${userData.email},
          ${userData.phone || null},
          ${userData.addresses ? JSON.stringify(userData.addresses) : null},
          ${userData.wishlist ? JSON.stringify(userData.wishlist) : null}
        )
        RETURNING *
      `

      return formatUserProfile(profile)
    }
  } catch (error) {
    console.error("Error creating user profile:", error)
    throw error
  }
}

export async function fetchUserProfile(userId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning null profile")
      return null
    }

    const [profile] = await sql`
      SELECT * FROM user_profiles
      WHERE user_id = ${userId}
    `

    if (!profile) return null

    return formatUserProfile(profile)
  } catch (error) {
    console.error("Error fetching user profile:", error)
    throw error
  }
}

export async function updateUserProfile(userId: string, userData: Partial<UserProfile>) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Build dynamic update query
    const updateFields = []
    const updateValues = []

    if (userData.firstName) {
      updateFields.push("first_name = $1")
      updateValues.push(userData.firstName)
    }

    if (userData.lastName) {
      updateFields.push(`last_name = $${updateValues.length + 1}`)
      updateValues.push(userData.lastName)
    }

    if (userData.email) {
      updateFields.push(`email = $${updateValues.length + 1}`)
      updateValues.push(userData.email)
    }

    if (userData.phone !== undefined) {
      updateFields.push(`phone = $${updateValues.length + 1}`)
      updateValues.push(userData.phone)
    }

    if (userData.addresses !== undefined) {
      updateFields.push(`addresses = $${updateValues.length + 1}`)
      updateValues.push(JSON.stringify(userData.addresses))
    }

    if (userData.wishlist !== undefined) {
      updateFields.push(`wishlist = $${updateValues.length + 1}`)
      updateValues.push(JSON.stringify(userData.wishlist))
    }

    // Add updated_at
    updateFields.push("updated_at = NOW()")

    if (updateFields.length === 0) {
      return true // Nothing to update
    }

    // Execute update
    await sql.query(`UPDATE user_profiles SET ${updateFields.join(", ")} WHERE user_id = $${updateValues.length + 1}`, [
      ...updateValues,
      userId,
    ])

    return true
  } catch (error) {
    console.error("Error updating user profile:", error)
    throw error
  }
}

// Wishlist operations
export async function addToWishlist(userId: string, productId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Get current wishlist
    const [profile] = await sql`
      SELECT wishlist FROM user_profiles
      WHERE user_id = ${userId}
    `

    if (!profile) {
      throw new Error("User profile not found")
    }

    // Update wishlist
    const wishlist = profile.wishlist || []
    if (!wishlist.includes(productId)) {
      wishlist.push(productId)

      await sql`
        UPDATE user_profiles
        SET wishlist = ${JSON.stringify(wishlist)}, updated_at = NOW()
        WHERE user_id = ${userId}
      `
    }

    return true
  } catch (error) {
    console.error("Error adding to wishlist:", error)
    throw error
  }
}

export async function removeFromWishlist(userId: string, productId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Get current wishlist
    const [profile] = await sql`
      SELECT wishlist FROM user_profiles
      WHERE user_id = ${userId}
    `

    if (!profile) {
      throw new Error("User profile not found")
    }

    // Update wishlist
    const wishlist = profile.wishlist || []
    const updatedWishlist = wishlist.filter((id) => id !== productId)

    await sql`
      UPDATE user_profiles
      SET wishlist = ${JSON.stringify(updatedWishlist)}, updated_at = NOW()
      WHERE user_id = ${userId}
    `

    return true
  } catch (error) {
    console.error("Error removing from wishlist:", error)
    throw error
  }
}

export async function fetchWishlistProducts(userId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning empty wishlist")
      return []
    }

    // Get wishlist
    const [profile] = await sql`
      SELECT wishlist FROM user_profiles
      WHERE user_id = ${userId}
    `

    if (!profile || !profile.wishlist || profile.wishlist.length === 0) {
      return []
    }

    // Fetch products
    const dbProducts = await sql`
      SELECT * FROM products
      WHERE id IN (${sql.join(profile.wishlist.map((id) => Number.parseInt(id)))})
    `

    return dbProducts.map(formatProduct)
  } catch (error) {
    console.error("Error fetching wishlist products:", error)
    throw error
  }
}

// Cart operations
export async function fetchCart(userId: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning empty cart")
      return { items: [] }
    }

    const [cart] = await sql`
      SELECT * FROM carts
      WHERE user_id = ${userId}
    `

    if (!cart) {
      return { items: [] }
    }

    return {
      id: cart.id.toString(),
      items: cart.items || [],
    }
  } catch (error) {
    console.error("Error fetching cart:", error)
    throw error
  }
}

export async function updateCart(userId: string, items: CartItem[]) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Check if cart exists
    const [existingCart] = await sql`
      SELECT * FROM carts
      WHERE user_id = ${userId}
    `

    if (existingCart) {
      // Update existing cart
      await sql`
        UPDATE carts
        SET items = ${JSON.stringify(items)}, updated_at = NOW()
        WHERE user_id = ${userId}
      `
    } else {
      // Create new cart
      await sql`
        INSERT INTO carts (user_id, items)
        VALUES (${userId}, ${JSON.stringify(items)})
      `
    }

    return true
  } catch (error) {
    console.error("Error updating cart:", error)
    throw error
  }
}

// Storage operations
export async function saveStorageRef(path: string, dataUrl: string, metadata: any = {}) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    // Check if ref exists
    const [existingRef] = await sql`
      SELECT * FROM storage_refs
      WHERE path = ${path}
    `

    if (existingRef) {
      // Update existing ref
      await sql`
        UPDATE storage_refs
        SET 
          data_url = ${dataUrl},
          content_type = ${metadata.contentType || null},
          name = ${metadata.name || null},
          size = ${metadata.size || null}
        WHERE path = ${path}
      `
    } else {
      // Create new ref
      await sql`
        INSERT INTO storage_refs (path, data_url, content_type, name, size)
        VALUES (
          ${path},
          ${dataUrl},
          ${metadata.contentType || null},
          ${metadata.name || null},
          ${metadata.size || null}
        )
      `
    }

    return true
  } catch (error) {
    console.error("Error saving storage ref:", error)
    throw error
  }
}

export async function getStorageRef(path: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      console.warn("Database not initialized, returning null storage ref")
      return null
    }

    const [ref] = await sql`
      SELECT * FROM storage_refs
      WHERE path = ${path}
    `

    if (!ref) {
      return null
    }

    return {
      path: ref.path,
      dataUrl: ref.data_url,
      contentType: ref.content_type,
      name: ref.name,
      size: ref.size,
      createdAt: ref.created_at,
    }
  } catch (error) {
    console.error("Error getting storage ref:", error)
    throw error
  }
}

export async function deleteStorageRef(path: string) {
  try {
    // Check if database is initialized
    const dbInitialized = await isDatabaseInitialized()
    if (!dbInitialized) {
      throw new Error("Database not initialized. Please set up the database first.")
    }

    await sql`
      DELETE FROM storage_refs
      WHERE path = ${path}
    `

    return true
  } catch (error) {
    console.error("Error deleting storage ref:", error)
    throw error
  }
}

// Helper functions to format data
function formatProduct(product): Product {
  return {
    id: product.id.toString(),
    name: product.name,
    slug: product.slug,
    description: product.description,
    price: product.price / 100, // Convert from cents to dollars
    compareAtPrice: product.compare_at_price ? product.compare_at_price / 100 : undefined,
    category: product.category_id?.toString(),
    images: product.images || [],
    featured: product.featured,
    isNew: product.is_new,
    isOnSale: product.is_on_sale,
    tags: product.tags || [],
    inventory: product.inventory,
    createdAt: product.created_at,
    updatedAt: product.updated_at,
  }
}

function formatCategory(category): Category {
  return {
    id: category.id.toString(),
    name: category.name,
    slug: category.slug,
    description: category.description,
    image: category.image,
  }
}

function formatOrder(order): Order {
  return {
    id: order.id.toString(),
    userId: order.user_id,
    items: order.items,
    subtotal: order.subtotal / 100, // Convert from cents to dollars
    tax: order.tax / 100,
    shipping: order.shipping / 100,
    total: order.total / 100,
    status: order.status,
    paymentMethod: order.payment_method,
    shippingAddress: order.shipping_address,
    createdAt: order.created_at,
    updatedAt: order.updated_at,
  }
}

function formatUserProfile(profile): UserProfile {
  return {
    id: profile.id.toString(),
    userId: profile.user_id,
    firstName: profile.first_name,
    lastName: profile.last_name,
    email: profile.email,
    phone: profile.phone,
    addresses: profile.addresses || [],
    wishlist: profile.wishlist || [],
    createdAt: profile.created_at,
    updatedAt: profile.updated_at,
  }
}

// We already imported and exported initializeLocalStorage at the top of the file
// No need to re-export it again here

export async function seedDatabase() {
  try {
    // Seed products
    const productsData = productData.map((product) => ({
      ...product,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }))

    localStorage.setItem("shapna_products", JSON.stringify(productsData))
    console.log("Seeded products successfully")

    // Seed categories
    const categoriesData = categoryData.map((category) => ({
      ...category,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    }))
    localStorage.setItem("shapna_categories", JSON.stringify(categoriesData))
    console.log("Seeded categories successfully")

    // Seed storage refs (optional, if needed)
    const storageRefs = {}
    localStorage.setItem("shapna_storage_refs", JSON.stringify(storageRefs))
    console.log("Seeded storage refs successfully")

    console.log("Database seeded successfully")
  } catch (error) {
    console.error("Error seeding database:", error)
  }
}

// Make sure any references to auth are using the Firebase auth
// If there are any direct references to the local storage auth, update them to use Firebase auth
// This is a placeholder for the actual changes needed in db-operations.ts

