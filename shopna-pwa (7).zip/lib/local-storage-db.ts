// Mock Firebase-like authentication and database for local storage

// Types
export interface User {
  uid: string
  email: string | null
  displayName: string | null
  photoURL: string | null
}

export interface AuthState {
  currentUser: User | null
  listeners: ((user: User | null) => void)[]
}

// Initialize local storage
export function initializeLocalStorage() {
  if (typeof window === "undefined") return

  // Initialize products if not exists
  if (!localStorage.getItem("shapna_products")) {
    localStorage.setItem("shapna_products", JSON.stringify([]))
  }

  // Initialize categories if not exists
  if (!localStorage.getItem("shapna_categories")) {
    localStorage.setItem("shapna_categories", JSON.stringify([]))
  }

  // Initialize users if not exists
  if (!localStorage.getItem("shapna_users")) {
    localStorage.setItem("shapna_users", JSON.stringify([]))
  }

  // Initialize auth state if not exists
  if (!localStorage.getItem("shapna_auth")) {
    localStorage.setItem("shapna_auth", JSON.stringify({ currentUser: null }))
  }

  // Initialize carts if not exists
  if (!localStorage.getItem("shapna_carts")) {
    localStorage.setItem("shapna_carts", JSON.stringify({}))
  }

  // Initialize orders if not exists
  if (!localStorage.getItem("shapna_orders")) {
    localStorage.setItem("shapna_orders", JSON.stringify([]))
  }

  // Initialize user profiles if not exists
  if (!localStorage.getItem("shapna_user_profiles")) {
    localStorage.setItem("shapna_user_profiles", JSON.stringify([]))
  }

  // Initialize storage refs if not exists
  if (!localStorage.getItem("shapna_storage_refs")) {
    localStorage.setItem("shapna_storage_refs", JSON.stringify({}))
  }

  console.log("Local storage initialized")
}

// Auth service
const authState: AuthState = {
  currentUser: null,
  listeners: [],
}

// Initialize auth state from localStorage
if (typeof window !== "undefined") {
  try {
    const storedAuth = localStorage.getItem("shapna_auth")
    if (storedAuth) {
      const parsedAuth = JSON.parse(storedAuth)
      authState.currentUser = parsedAuth.currentUser
    }
  } catch (error) {
    console.error("Error initializing auth state from localStorage:", error)
  }
}

export const auth = {
  currentUser: authState.currentUser,

  onAuthStateChanged(callback: (user: User | null) => void) {
    authState.listeners.push(callback)
    callback(authState.currentUser)

    return () => {
      authState.listeners = authState.listeners.filter((listener) => listener !== callback)
    }
  },

  async createUserWithEmailAndPassword(email: string, password: string) {
    if (typeof window === "undefined") {
      throw new Error("Cannot create user in server environment")
    }

    try {
      // Check if user already exists
      const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
      const existingUser = users.find((user: any) => user.email === email)

      if (existingUser) {
        throw new Error("User already exists")
      }

      // Create new user
      const newUser: User = {
        uid: `user_${Date.now()}`,
        email,
        displayName: email.split("@")[0],
        photoURL: null,
      }

      // Add user to users array
      users.push({
        ...newUser,
        password, // In a real app, NEVER store passwords in plain text
      })

      localStorage.setItem("shapna_users", JSON.stringify(users))

      // Update auth state
      authState.currentUser = newUser
      localStorage.setItem("shapna_auth", JSON.stringify({ currentUser: newUser }))

      // Notify listeners
      authState.listeners.forEach((listener) => listener(newUser))

      return { user: newUser }
    } catch (error) {
      console.error("Error creating user:", error)
      throw error
    }
  },

  async signInWithEmailAndPassword(email: string, password: string) {
    if (typeof window === "undefined") {
      throw new Error("Cannot sign in in server environment")
    }

    try {
      // Find user
      const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
      const user = users.find((user: any) => user.email === email && user.password === password)

      if (!user) {
        throw new Error("Invalid email or password")
      }

      // Update auth state
      const userData: User = {
        uid: user.uid,
        email: user.email,
        displayName: user.displayName,
        photoURL: user.photoURL,
      }

      authState.currentUser = userData
      localStorage.setItem("shapna_auth", JSON.stringify({ currentUser: userData }))

      // Notify listeners
      authState.listeners.forEach((listener) => listener(userData))

      return { user: userData }
    } catch (error) {
      console.error("Error signing in:", error)
      throw error
    }
  },

  async signOut() {
    if (typeof window === "undefined") {
      throw new Error("Cannot sign out in server environment")
    }

    try {
      // Update auth state
      authState.currentUser = null
      localStorage.setItem("shapna_auth", JSON.stringify({ currentUser: null }))

      // Notify listeners
      authState.listeners.forEach((listener) => listener(null))
    } catch (error) {
      console.error("Error signing out:", error)
      throw error
    }
  },
}

// Database service
export const db = {
  collection(collectionName: string) {
    return {
      doc(docId: string) {
        return {
          get: async () => {
            if (typeof window === "undefined") {
              throw new Error("Cannot access database in server environment")
            }

            try {
              let data

              switch (collectionName) {
                case "users":
                  const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                  data = users.find((user: any) => user.uid === docId)
                  break

                case "user_profiles":
                  const profiles = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                  data = profiles.find((profile: any) => profile.userId === docId)
                  break

                case "carts":
                  const carts = JSON.parse(localStorage.getItem("shapna_carts") || "{}")
                  data = carts[docId]
                  break

                case "orders":
                  const orders = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                  data = orders.find((order: any) => order.id === docId)
                  break

                default:
                  data = null
              }

              return {
                exists: !!data,
                data: () => data || null,
              }
            } catch (error) {
              console.error(`Error getting document ${docId} from ${collectionName}:`, error)
              throw error
            }
          },

          set: async (data: any) => {
            if (typeof window === "undefined") {
              throw new Error("Cannot access database in server environment")
            }

            try {
              switch (collectionName) {
                case "users":
                  const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                  const userIndex = users.findIndex((user: any) => user.uid === docId)

                  if (userIndex >= 0) {
                    users[userIndex] = { ...users[userIndex], ...data }
                  } else {
                    users.push({ uid: docId, ...data })
                  }

                  localStorage.setItem("shapna_users", JSON.stringify(users))
                  break

                case "user_profiles":
                  const profiles = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                  const profileIndex = profiles.findIndex((profile: any) => profile.userId === docId)

                  if (profileIndex >= 0) {
                    profiles[profileIndex] = { ...profiles[profileIndex], ...data }
                  } else {
                    profiles.push({ userId: docId, ...data })
                  }

                  localStorage.setItem("shapna_user_profiles", JSON.stringify(profiles))
                  break

                case "carts":
                  const carts = JSON.parse(localStorage.getItem("shapna_carts") || "{}")
                  carts[docId] = data
                  localStorage.setItem("shapna_carts", JSON.stringify(carts))
                  break

                case "orders":
                  const orders = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                  const orderIndex = orders.findIndex((order: any) => order.id === docId)

                  if (orderIndex >= 0) {
                    orders[orderIndex] = { ...orders[orderIndex], ...data }
                  } else {
                    orders.push({ id: docId, ...data })
                  }

                  localStorage.setItem("shapna_orders", JSON.stringify(orders))
                  break

                default:
                // Do nothing
              }
            } catch (error) {
              console.error(`Error setting document ${docId} in ${collectionName}:`, error)
              throw error
            }
          },

          update: async (data: any) => {
            if (typeof window === "undefined") {
              throw new Error("Cannot access database in server environment")
            }

            try {
              switch (collectionName) {
                case "users":
                  const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                  const userIndex = users.findIndex((user: any) => user.uid === docId)

                  if (userIndex >= 0) {
                    users[userIndex] = { ...users[userIndex], ...data }
                    localStorage.setItem("shapna_users", JSON.stringify(users))
                  } else {
                    throw new Error(`User with ID ${docId} not found`)
                  }
                  break

                case "user_profiles":
                  const profiles = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                  const profileIndex = profiles.findIndex((profile: any) => profile.userId === docId)

                  if (profileIndex >= 0) {
                    profiles[profileIndex] = { ...profiles[profileIndex], ...data }
                    localStorage.setItem("shapna_user_profiles", JSON.stringify(profiles))
                  } else {
                    throw new Error(`User profile with ID ${docId} not found`)
                  }
                  break

                case "carts":
                  const carts = JSON.parse(localStorage.getItem("shapna_carts") || "{}")

                  if (carts[docId]) {
                    carts[docId] = { ...carts[docId], ...data }
                    localStorage.setItem("shapna_carts", JSON.stringify(carts))
                  } else {
                    throw new Error(`Cart with ID ${docId} not found`)
                  }
                  break

                case "orders":
                  const orders = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                  const orderIndex = orders.findIndex((order: any) => order.id === docId)

                  if (orderIndex >= 0) {
                    orders[orderIndex] = { ...orders[orderIndex], ...data }
                    localStorage.setItem("shapna_orders", JSON.stringify(orders))
                  } else {
                    throw new Error(`Order with ID ${docId} not found`)
                  }
                  break

                default:
                  throw new Error(`Collection ${collectionName} not supported`)
              }
            } catch (error) {
              console.error(`Error updating document ${docId} in ${collectionName}:`, error)
              throw error
            }
          },
        }
      },

      where(field: string, operator: string, value: any) {
        return {
          get: async () => {
            if (typeof window === "undefined") {
              throw new Error("Cannot access database in server environment")
            }

            try {
              let items: any[] = []

              switch (collectionName) {
                case "users":
                  items = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                  break

                case "user_profiles":
                  items = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                  break

                case "orders":
                  items = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                  break

                case "products":
                  items = JSON.parse(localStorage.getItem("shapna_products") || "[]")
                  break

                case "categories":
                  items = JSON.parse(localStorage.getItem("shapna_categories") || "[]")
                  break

                default:
                  items = []
              }

              // Filter items based on query
              let filteredItems

              switch (operator) {
                case "==":
                  filteredItems = items.filter((item) => item[field] === value)
                  break

                case "!=":
                  filteredItems = items.filter((item) => item[field] !== value)
                  break

                case ">":
                  filteredItems = items.filter((item) => item[field] > value)
                  break

                case ">=":
                  filteredItems = items.filter((item) => item[field] >= value)
                  break

                case "<":
                  filteredItems = items.filter((item) => item[field] < value)
                  break

                case "<=":
                  filteredItems = items.filter((item) => item[field] <= value)
                  break

                case "array-contains":
                  filteredItems = items.filter((item) => Array.isArray(item[field]) && item[field].includes(value))
                  break

                default:
                  filteredItems = []
              }

              return {
                empty: filteredItems.length === 0,
                size: filteredItems.length,
                docs: filteredItems.map((item) => ({
                  id: item.id || item.uid || item.userId,
                  exists: true,
                  data: () => item,
                })),
              }
            } catch (error) {
              console.error(`Error querying ${collectionName} where ${field} ${operator} ${value}:`, error)
              throw error
            }
          },
        }
      },

      orderBy(field: string, direction: "asc" | "desc" = "asc") {
        return {
          limit(limitCount: number) {
            return {
              get: async () => {
                if (typeof window === "undefined") {
                  throw new Error("Cannot access database in server environment")
                }

                try {
                  let items: any[] = []

                  switch (collectionName) {
                    case "users":
                      items = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                      break

                    case "user_profiles":
                      items = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                      break

                    case "orders":
                      items = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                      break

                    case "products":
                      items = JSON.parse(localStorage.getItem("shapna_products") || "[]")
                      break

                    case "categories":
                      items = JSON.parse(localStorage.getItem("shapna_categories") || "[]")
                      break

                    default:
                      items = []
                  }

                  // Sort items
                  items.sort((a, b) => {
                    if (direction === "asc") {
                      return a[field] > b[field] ? 1 : -1
                    } else {
                      return a[field] < b[field] ? 1 : -1
                    }
                  })

                  // Apply limit
                  const limitedItems = items.slice(0, limitCount)

                  return {
                    empty: limitedItems.length === 0,
                    size: limitedItems.length,
                    docs: limitedItems.map((item) => ({
                      id: item.id || item.uid || item.userId,
                      exists: true,
                      data: () => item,
                    })),
                  }
                } catch (error) {
                  console.error(`Error querying ${collectionName} ordered by ${field}:`, error)
                  throw error
                }
              },
            }
          },

          get: async () => {
            if (typeof window === "undefined") {
              throw new Error("Cannot access database in server environment")
            }

            try {
              let items: any[] = []

              switch (collectionName) {
                case "users":
                  items = JSON.parse(localStorage.getItem("shapna_users") || "[]")
                  break

                case "user_profiles":
                  items = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
                  break

                case "orders":
                  items = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
                  break

                case "products":
                  items = JSON.parse(localStorage.getItem("shapna_products") || "[]")
                  break

                case "categories":
                  items = JSON.parse(localStorage.getItem("shapna_categories") || "[]")
                  break

                default:
                  items = []
              }

              // Sort items
              items.sort((a, b) => {
                if (direction === "asc") {
                  return a[field] > b[field] ? 1 : -1
                } else {
                  return a[field] < b[field] ? 1 : -1
                }
              })

              return {
                empty: items.length === 0,
                size: items.length,
                docs: items.map((item) => ({
                  id: item.id || item.uid || item.userId,
                  exists: true,
                  data: () => item,
                })),
              }
            } catch (error) {
              console.error(`Error querying ${collectionName} ordered by ${field}:`, error)
              throw error
            }
          },
        }
      },

      get: async () => {
        if (typeof window === "undefined") {
          throw new Error("Cannot access database in server environment")
        }

        try {
          let items: any[] = []

          switch (collectionName) {
            case "users":
              items = JSON.parse(localStorage.getItem("shapna_users") || "[]")
              break

            case "user_profiles":
              items = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
              break

            case "orders":
              items = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
              break

            case "products":
              items = JSON.parse(localStorage.getItem("shapna_products") || "[]")
              break

            case "categories":
              items = JSON.parse(localStorage.getItem("shapna_categories") || "[]")
              break

            default:
              items = []
          }

          return {
            empty: items.length === 0,
            size: items.length,
            docs: items.map((item) => ({
              id: item.id || item.uid || item.userId,
              exists: true,
              data: () => item,
            })),
          }
        } catch (error) {
          console.error(`Error getting collection ${collectionName}:`, error)
          throw error
        }
      },

      add: async (data: any) => {
        if (typeof window === "undefined") {
          throw new Error("Cannot access database in server environment")
        }

        try {
          const id = `${collectionName}_${Date.now()}`
          const newItem = { id, ...data }

          switch (collectionName) {
            case "users":
              const users = JSON.parse(localStorage.getItem("shapna_users") || "[]")
              users.push(newItem)
              localStorage.setItem("shapna_users", JSON.stringify(users))
              break

            case "user_profiles":
              const profiles = JSON.parse(localStorage.getItem("shapna_user_profiles") || "[]")
              profiles.push(newItem)
              localStorage.setItem("shapna_user_profiles", JSON.stringify(profiles))
              break

            case "orders":
              const orders = JSON.parse(localStorage.getItem("shapna_orders") || "[]")
              orders.push(newItem)
              localStorage.setItem("shapna_orders", JSON.stringify(orders))
              break

            case "products":
              const products = JSON.parse(localStorage.getItem("shapna_products") || "[]")
              products.push(newItem)
              localStorage.setItem("shapna_products", JSON.stringify(products))
              break

            case "categories":
              const categories = JSON.parse(localStorage.getItem("shapna_categories") || "[]")
              categories.push(newItem)
              localStorage.setItem("shapna_categories", JSON.stringify(categories))
              break

            default:
              throw new Error(`Collection ${collectionName} not supported`)
          }

          return {
            id,
            get: async () => ({
              exists: true,
              data: () => newItem,
            }),
          }
        } catch (error) {
          console.error(`Error adding document to ${collectionName}:`, error)
          throw error
        }
      },
    }
  },
}

// Helper for timestamps
export const serverTimestamp = () => new Date().toISOString()

