import { sql } from "./db"
import { products, categories } from "./product-data"

export async function seedDatabase() {
  try {
    console.log("Seeding database...")

    // Seed categories
    console.log("Seeding categories...")
    for (const category of categories) {
      await sql`
        INSERT INTO categories (name, slug, description, image)
        VALUES (
          ${category.name},
          ${category.slug},
          ${category.description},
          ${category.image}
        )
        ON CONFLICT (slug) DO UPDATE
        SET 
          name = ${category.name},
          description = ${category.description},
          image = ${category.image},
          updated_at = NOW()
      `
    }

    // Seed products
    console.log("Seeding products...")
    for (const product of products) {
      // Find category ID
      let categoryId = null
      if (product.category) {
        const [category] = await sql`
          SELECT id FROM categories WHERE id = ${product.category}
        `
        if (category) {
          categoryId = category.id
        }
      }

      await sql`
        INSERT INTO products (
          name, slug, description, price, compare_at_price, 
          category_id, images, featured, is_new, is_on_sale, 
          tags, inventory
        )
        VALUES (
          ${product.name},
          ${product.slug},
          ${product.description},
          ${Math.round(product.price * 100)}, 
          ${product.compareAtPrice ? Math.round(product.compareAtPrice * 100) : null},
          ${categoryId},
          ${JSON.stringify(product.images)},
          ${product.featured || false},
          ${product.isNew || false},
          ${product.isOnSale || false},
          ${JSON.stringify(product.tags || [])},
          ${product.inventory || 0}
        )
        ON CONFLICT (slug) DO UPDATE
        SET 
          name = ${product.name},
          description = ${product.description},
          price = ${Math.round(product.price * 100)},
          compare_at_price = ${product.compareAtPrice ? Math.round(product.compareAtPrice * 100) : null},
          category_id = ${categoryId},
          images = ${JSON.stringify(product.images)},
          featured = ${product.featured || false},
          is_new = ${product.isNew || false},
          is_on_sale = ${product.isOnSale || false},
          tags = ${JSON.stringify(product.tags || [])},
          inventory = ${product.inventory || 0},
          updated_at = NOW()
      `
    }

    console.log("Database seeded successfully")
    return true
  } catch (error) {
    console.error("Error seeding database:", error)
    throw error
  }
}

