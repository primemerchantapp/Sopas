import { sql } from "./db"
import { products as productData, categories as categoryData } from "./product-data"

export async function seedDatabase() {
  console.log("Seeding database...")

  try {
    // Check if categories already exist
    const existingCategories = await sql`SELECT COUNT(*) FROM categories`
    if (existingCategories[0].count === "0") {
      // Seed categories
      for (const category of categoryData) {
        await sql`
          INSERT INTO categories (name, slug, description, image)
          VALUES (${category.name}, ${category.slug}, ${category.description || ""}, ${category.image || ""})
        `
      }
      console.log("Categories seeded successfully")
    } else {
      console.log("Categories already exist, skipping seed")
    }

    // Check if products already exist
    const existingProducts = await sql`SELECT COUNT(*) FROM products`
    if (existingProducts[0].count === "0") {
      // Get category IDs
      const categories = await sql`SELECT id, slug FROM categories`
      const categoryMap = categories.reduce((map, cat) => {
        map[cat.slug] = cat.id
        return map
      }, {})

      // Seed products
      for (const product of productData) {
        const categoryId = categoryMap[product.category] || null

        await sql`
          INSERT INTO products (
            name, slug, description, price, compare_at_price, 
            category_id, images, featured, is_new, is_on_sale, tags, inventory
          )
          VALUES (
            ${product.name}, 
            ${product.slug || product.name.toLowerCase().replace(/\s+/g, "-")}, 
            ${product.description}, 
            ${Math.round(product.price * 100)}, 
            ${product.compareAtPrice ? Math.round(product.compareAtPrice * 100) : null}, 
            ${categoryId}, 
            ${JSON.stringify(product.images || [])}, 
            ${product.featured || false}, 
            ${product.isNew || false}, 
            ${product.isOnSale || false}, 
            ${JSON.stringify(product.tags || [])}, 
            ${product.inventory || 0}
          )
        `
      }
      console.log("Products seeded successfully")
    } else {
      console.log("Products already exist, skipping seed")
    }

    console.log("Database seeded successfully")
  } catch (error) {
    console.error("Error seeding database:", error)
    throw error
  }
}

