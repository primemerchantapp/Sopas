import { pgTable, serial, text, timestamp, integer, boolean, json, pgEnum } from "drizzle-orm/pg-core"

// Users table
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  uid: text("uid").notNull().unique(),
  email: text("email"),
  displayName: text("display_name"),
  createdAt: timestamp("created_at").defaultNow(),
})

// User profiles table
export const userProfiles = pgTable("user_profiles", {
  id: serial("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.uid),
  firstName: text("first_name").notNull(),
  lastName: text("last_name").notNull(),
  email: text("email").notNull(),
  phone: text("phone"),
  addresses:
    json("addresses").$type<
      {
        id: string
        name: string
        address: string
        city: string
        state: string
        zipCode: string
        isDefault: boolean
      }[]
    >(),
  wishlist: json("wishlist").$type<string[]>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Categories table
export const categories = pgTable("categories", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description"),
  image: text("image"),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Products table
export const products = pgTable("products", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  slug: text("slug").notNull().unique(),
  description: text("description").notNull(),
  price: integer("price").notNull(), // Store in cents
  compareAtPrice: integer("compare_at_price"), // Store in cents
  categoryId: integer("category_id").references(() => categories.id),
  images: json("images").$type<string[]>(),
  featured: boolean("featured").default(false),
  isNew: boolean("is_new").default(false),
  isOnSale: boolean("is_on_sale").default(false),
  tags: json("tags").$type<string[]>(),
  inventory: integer("inventory").default(0),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Order status enum
export const orderStatusEnum = pgEnum("order_status", ["pending", "processing", "shipped", "delivered", "cancelled"])

// Orders table
export const orders = pgTable("orders", {
  id: serial("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.uid),
  items:
    json("items").$type<
      {
        id: string
        name: string
        price: number
        image: string
        quantity: number
      }[]
    >(),
  subtotal: integer("subtotal").notNull(), // Store in cents
  tax: integer("tax").notNull(), // Store in cents
  shipping: integer("shipping").notNull(), // Store in cents
  total: integer("total").notNull(), // Store in cents
  status: orderStatusEnum("status").default("pending"),
  paymentMethod: text("payment_method").notNull(),
  shippingAddress: json("shipping_address").$type<{
    name: string
    address: string
    city: string
    state: string
    zipCode: string
    phone: string
  }>(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Carts table
export const carts = pgTable("carts", {
  id: serial("id").primaryKey(),
  userId: text("user_id")
    .notNull()
    .references(() => users.uid),
  items:
    json("items").$type<
      {
        id: string
        name: string
        price: number
        image: string
        quantity: number
      }[]
    >(),
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
})

// Storage references table
export const storageRefs = pgTable("storage_refs", {
  id: serial("id").primaryKey(),
  path: text("path").notNull().unique(),
  dataUrl: text("data_url").notNull(),
  contentType: text("content_type"),
  name: text("name"),
  size: integer("size"),
  createdAt: timestamp("created_at").defaultNow(),
})

