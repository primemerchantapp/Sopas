import { sql } from "./db"

export async function createDatabaseSchema() {
  try {
    console.log("Creating database schema...")

    // Create enum types
    await sql`
      DO $$ 
      BEGIN
        IF NOT EXISTS (SELECT 1 FROM pg_type WHERE typname = 'order_status') THEN
          CREATE TYPE order_status AS ENUM (
            'pending', 'processing', 'shipped', 'delivered', 'cancelled'
          );
        END IF;
      END $$;
    `

    // Create users table
    await sql`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        uid TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        display_name TEXT,
        photo_url TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create categories table
    await sql`
      CREATE TABLE IF NOT EXISTS categories (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        image TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create products table
    await sql`
      CREATE TABLE IF NOT EXISTS products (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        slug TEXT UNIQUE NOT NULL,
        description TEXT,
        price INTEGER NOT NULL,
        compare_at_price INTEGER,
        category_id INTEGER REFERENCES categories(id),
        images JSONB DEFAULT '[]'::jsonb,
        featured BOOLEAN DEFAULT false,
        is_new BOOLEAN DEFAULT false,
        is_on_sale BOOLEAN DEFAULT false,
        tags JSONB DEFAULT '[]'::jsonb,
        inventory INTEGER DEFAULT 0,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create user_profiles table
    await sql`
      CREATE TABLE IF NOT EXISTS user_profiles (
        id SERIAL PRIMARY KEY,
        user_id TEXT UNIQUE NOT NULL REFERENCES users(uid),
        first_name TEXT,
        last_name TEXT,
        email TEXT,
        phone TEXT,
        addresses JSONB DEFAULT '[]'::jsonb,
        wishlist JSONB DEFAULT '[]'::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create orders table
    await sql`
      CREATE TABLE IF NOT EXISTS orders (
        id SERIAL PRIMARY KEY,
        user_id TEXT NOT NULL REFERENCES users(uid),
        items JSONB NOT NULL,
        subtotal INTEGER NOT NULL,
        tax INTEGER NOT NULL,
        shipping INTEGER NOT NULL,
        total INTEGER NOT NULL,
        status order_status NOT NULL DEFAULT 'pending',
        payment_method TEXT NOT NULL,
        shipping_address JSONB NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create carts table
    await sql`
      CREATE TABLE IF NOT EXISTS carts (
        id SERIAL PRIMARY KEY,
        user_id TEXT UNIQUE NOT NULL REFERENCES users(uid),
        items JSONB DEFAULT '[]'::jsonb,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    // Create storage_refs table
    await sql`
      CREATE TABLE IF NOT EXISTS storage_refs (
        id SERIAL PRIMARY KEY,
        path TEXT UNIQUE NOT NULL,
        data_url TEXT NOT NULL,
        content_type TEXT,
        name TEXT,
        size INTEGER,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
      )
    `

    console.log("Database schema created successfully")
    return true
  } catch (error) {
    console.error("Error creating database schema:", error)
    throw error
  }
}

