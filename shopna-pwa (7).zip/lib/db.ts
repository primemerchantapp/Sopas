import { neon } from "@neondatabase/serverless"
import { drizzle } from "drizzle-orm/neon-http"

// Initialize SQL and DB with conditional logic
let sql
let db

// Function to initialize the database connection
export function initializeDb() {
  // Check if DATABASE_URL is defined
  if (!process.env.DATABASE_URL) {
    console.error("DATABASE_URL environment variable is not set")
    // Return a dummy SQL function that throws a clear error when used
    return {
      sql: () => {
        throw new Error("Database connection not initialized. Please set the DATABASE_URL environment variable.")
      },
      db: null,
    }
  }

  try {
    // Create a SQL executor with a connection pool
    const sqlInstance = neon(process.env.DATABASE_URL)
    // Create a drizzle client
    const dbInstance = drizzle(sqlInstance)

    return { sql: sqlInstance, db: dbInstance }
  } catch (error) {
    console.error("Failed to initialize database:", error)
    throw error
  }
}

// Initialize database connection lazily
export function getDb() {
  if (!sql || !db) {
    const connection = initializeDb()
    sql = connection.sql
    db = connection.db
  }
  return { sql, db }
}

// Export a function to check database connection
export async function checkDatabaseConnection() {
  try {
    if (!process.env.DATABASE_URL) {
      return {
        connected: false,
        error: "DATABASE_URL environment variable is not set",
      }
    }

    const { sql } = getDb()
    // Try a simple query to check connection
    const result = await sql`SELECT 1 as connected`
    return { connected: result[0]?.connected === 1 }
  } catch (error) {
    console.error("Database connection error:", error)
    return {
      connected: false,
      error: error instanceof Error ? error.message : "Unknown database error",
    }
  }
}

export { sql }

