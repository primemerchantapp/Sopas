import { exec } from "child_process"
import { promisify } from "util"

const execAsync = promisify(exec)

async function setupProducts() {
  try {
    console.log("🚀 Starting product setup process...")

    // Step 1: Download CSV
    console.log("\n📥 Downloading product CSV file...")
    await execAsync("npx tsx scripts/download-csv.ts")

    // Step 2: Seed products
    console.log("\n🌱 Seeding products into database...")
    await execAsync("npx tsx scripts/seed-products.ts")

    console.log("\n✅ Setup complete! Your products have been added to the database.")
  } catch (error) {
    console.error("❌ Error in setup process:", error)
  }
}

setupProducts()

