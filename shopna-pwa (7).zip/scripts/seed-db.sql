-- Seed data for SoPas E-commerce Platform

-- Insert categories
INSERT INTO categories (name, slug, description, image) VALUES
('Clothing', 'clothing', 'All types of clothing items', 'categories/clothing.jpg'),
('Shoes', 'shoes', 'Footwear for all occasions', 'categories/shoes.jpg'),
('Accessories', 'accessories', 'Enhance your style with our accessories', 'categories/accessories.jpg'),
('Electronics', 'electronics', 'Latest gadgets and electronics', 'categories/electronics.jpg'),
('Home Decor', 'home-decor', 'Beautify your living space', 'categories/home-decor.jpg'),
('Beauty', 'beauty', 'Skincare and beauty products', 'categories/beauty.jpg'),
('Sports', 'sports', 'Sports and fitness equipment', 'categories/sports.jpg'),
('Books', 'books', 'Books and stationery items', 'categories/books.jpg')
ON CONFLICT (slug) DO NOTHING;

-- Insert products
INSERT INTO products (name, slug, description, price, compare_at_price, category_id, images, featured, is_new, is_on_sale, tags, inventory) VALUES
('Premium Cotton T-Shirt', 'premium-cotton-t-shirt', '100% organic cotton t-shirt with premium finish. Minimalist design and modern cut that adapts to any style.', 59900, 79900, 1, '["products/tshirt-1.jpg", "products/tshirt-2.jpg"]', TRUE, FALSE, TRUE, '["summer", "cotton", "casual"]', 12),
('Urban Sports Shoes', 'urban-sports-shoes', 'Urban design shoes with advanced technology for maximum comfort. Ideal for daily use and light sports activities.', 249900, NULL, 2, '["products/shoes-1.jpg"]', TRUE, TRUE, FALSE, '["sports", "urban", "comfort"]', 8),
('Premium Wireless Headphones', 'premium-wireless-headphones', 'Headphones with noise cancellation, high definition sound and long battery life. Ergonomic design for maximum comfort.', 499900, 599900, 4, '["products/headphones-1.jpg", "products/headphones-2.jpg"]', TRUE, FALSE, TRUE, '["audio", "wireless", "technology"]', 15),
('Leather Crossbody Bag', 'leather-crossbody-bag', 'Genuine leather crossbody bag with premium finish. Spacious and functional with multiple compartments and adjustable strap.', 189900, NULL, 3, '["products/bag-1.jpg"]', TRUE, FALSE, FALSE, '["leather", "bag", "fashion"]', 5),
('Polarized Sunglasses', 'polarized-sunglasses', 'Sunglasses with UV400 protection and polarized lenses. Lightweight and durable frame with timeless design.', 129900, 179900, 3, '["products/sunglasses-1.jpg"]', FALSE, FALSE, TRUE, '["glasses", "summer", "protection"]', 3),
('Slim Fit Chinos', 'slim-fit-chinos', 'Chino pants with slim fit cut and stretch fabric for greater comfort. Versatile for formal or casual occasions.', 149900, NULL, 1, '["products/chinos-1.jpg"]', FALSE, FALSE, FALSE, '["pants", "formal", "casual"]', 7),
('Sports Smartwatch', 'sports-smartwatch', 'Smartwatch with heart rate monitor, built-in GPS and long battery life. Water resistant and compatible with iOS and Android.', 389900, 459900, 4, '["products/smartwatch-1.jpg"]', FALSE, TRUE, TRUE, '["smartwatch", "fitness", "wearable"]', 10),
('Large Scented Candle', 'large-scented-candle', 'Handcrafted scented candle with soy wax and essential oils. Long-lasting fragrance and reusable container.', 69900, NULL, 5, '["products/candle-1.jpg"]', FALSE, FALSE, FALSE, '["home", "scents", "decoration"]', 20),
('Natural Skincare Set', 'natural-skincare-set', 'Complete skincare set with natural and organic ingredients. Includes cleanser, toner, serum and moisturizer.', 199900, NULL, 6, '["products/skincare-1.jpg"]', FALSE, TRUE, FALSE, '["beauty", "skincare", "natural"]', 9),
('Vintage Denim Jacket', 'vintage-denim-jacket', 'Denim jacket with vintage finish and distressed details. Oversized cut and functional pockets.', 249900, NULL, 1, '["products/jacket-1.jpg"]', FALSE, FALSE, FALSE, '["denim", "vintage", "outerwear"]', 6),
('Amazon Echo Dot (5th Generation)', 'amazon-echo-dot-5th-generation', 'Smart speaker with improved sound and Alexa. Voice control your entertainment, get answers to your questions, and easily control your smart home.', 9999, 12999, 4, '["products/echo-dot.jpg"]', TRUE, TRUE, TRUE, '["smart home", "speaker", "alexa"]', 50)
ON CONFLICT (slug) DO NOTHING;

-- Insert shipping methods
INSERT INTO shipping_methods (name, description, price, is_active) VALUES
('Standard Shipping', 'Delivery within 5-7 business days', 9900, TRUE),
('Express Shipping', 'Delivery within 2-3 business days', 19900, TRUE),
('Same Day Delivery', 'Delivery on the same day for orders before 12pm', 29900, TRUE),
('Free Shipping', 'Free shipping for orders over ₱1,000', 0, TRUE)
ON CONFLICT DO NOTHING;

-- Insert payment methods
INSERT INTO payment_methods (name, description, is_active) VALUES
('Credit/Debit Card', 'Pay securely with your credit or debit card', TRUE),
('Cash on Delivery', 'Pay when you receive your order', TRUE),
('GCash', 'Pay using your GCash account', TRUE),
('PayMongo', 'Pay using PayMongo payment gateway', TRUE),
('Bank Transfer', 'Pay via bank transfer', TRUE)
ON CONFLICT DO NOTHING;

-- Insert store locations
INSERT INTO store_locations (name, address, city, state, postal_code, country, phone, email, opening_hours, is_active) VALUES
('SoPas Main Branch', '123 Main Street', 'Makati City', 'Metro Manila', '1200', 'Philippines', '+639123456789', 'makati@sopas.com', 'Monday - Friday: 9:00 AM - 8:00 PM\nSaturday: 10:00 AM - 6:00 PM\nSunday: 10:00 AM - 4:00 PM', TRUE),
('SoPas Quezon City', '456 Commonwealth Avenue', 'Quezon City', 'Metro Manila', '1121', 'Philippines', '+639987654321', 'qc@sopas.com', 'Monday - Friday: 9:00 AM - 8:00 PM\nSaturday: 10:00 AM - 6:00 PM\nSunday: 10:00 AM - 4:00 PM', TRUE)
ON CONFLICT DO NOTHING;

-- Insert coupons
INSERT INTO coupons (code, description, discount_type, discount_value, minimum_purchase, start_date, end_date, usage_limit, is_active) VALUES
('WELCOME10', 'Get 10% off your first order', 'percentage', 1000, 50000, '2023-01-01 00:00:00', '2025-12-31 23:59:59', 1, TRUE),
('SUMMER25', '25% off summer collection', 'percentage', 2500, 100000, '2023-06-01 00:00:00', '2023-08-31 23:59:59', 0, TRUE),
('FREESHIP', 'Free shipping on all orders', 'fixed', 9900, 0, '2023-01-01 00:00:00', '2025-12-31 23:59:59', 0, TRUE)
ON CONFLICT DO NOTHING;

-- Insert storage references for product images
INSERT INTO storage_refs (path, data_url, content_type, name) VALUES
('products/echo-dot.jpg', 'https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Amazon-Echo-Dot-5th-Generation-Without-Clock-pDr4ZwczwJaz3InTD7nV6wUUeGSNhb.png', 'image/jpeg', 'Amazon Echo Dot')
ON CONFLICT (path) DO NOTHING;

