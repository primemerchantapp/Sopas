import { sql } from "@/lib/db"
import fs from "fs"
import path from "path"

async function setupDatabase() {
  try {
    console.log("Starting database setup...")

    // Read migration SQL
    const migrationSql = fs.readFileSync(path.join(process.cwd(), "scripts", "migrate-db.sql"), "utf8")

    // Read seed SQL
    const seedSql = fs.readFileSync(path.join(process.cwd(), "scripts", "seed-db.sql"), "utf8")

    // Execute migration
    console.log("Creating database schema...")
    await sql.query(migrationSql)
    console.log("Database schema created successfully")

    // Execute seed
    console.log("Seeding database with initial data...")
    await sql.query(seedSql)
    console.log("Database seeded successfully")

    console.log("Database setup completed successfully")
    return { success: true }
  } catch (error) {
    console.error("Error setting up database:", error)
    return { success: false, error }
  }
}

// Execute if run directly
if (require.main === module) {
  setupDatabase()
    .then((result) => {
      if (result.success) {
        console.log("✅ Database setup completed successfully")
        process.exit(0)
      } else {
        console.error("❌ Database setup failed:", result.error)
        process.exit(1)
      }
    })
    .catch((error) => {
      console.error("❌ Unhandled error during database setup:", error)
      process.exit(1)
    })
}

export default setupDatabase

