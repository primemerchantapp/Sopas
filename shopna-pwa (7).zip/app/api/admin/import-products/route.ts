import { NextResponse } from "next/server"
import { sql } from "@/lib/db"
import fs from "fs"
import path from "path"
import { parse } from "csv-parse/sync"

// Function to save image to storage
async function saveImageToStorage(imageUrl: string, productHandle: string) {
  try {
    // For demo purposes, we'll use the image URL directly
    // In a production app, you would fetch and store the image
    const imageId = `${productHandle}-${Date.now()}`

    // Save reference in storage_refs table
    await sql`
      INSERT INTO storage_refs (
        path, 
        data_url, 
        content_type, 
        name,
        size
      ) VALUES (
        ${`products/${imageId}`},
        ${imageUrl},
        ${"image/jpeg"},
        ${productHandle},
        ${0}
      )
      ON CONFLICT (path) DO UPDATE
      SET 
        data_url = ${imageUrl},
        updated_at = NOW()
    `

    return `products/${imageId}`
  } catch (error) {
    console.error("Error saving image to storage:", error)
    return null
  }
}

export async function POST() {
  try {
    // Check if products and categories tables exist
    const tablesExist = await sql`
      SELECT EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public'
        AND table_name = 'products'
      ) AND EXISTS (
        SELECT FROM information_schema.tables 
        WHERE table_schema = 'public'
        AND table_name = 'categories'
      ) as exists
    `

    if (!tablesExist[0]?.exists) {
      throw new Error("Database tables do not exist. Please initialize the database first.")
    }

    // Clear existing products
    await sql`TRUNCATE products RESTART IDENTITY CASCADE`

    // Read CSV file - use path to downloaded file
    const csvFilePath = path.resolve(process.cwd(), "data", "products_export.csv")

    if (!fs.existsSync(csvFilePath)) {
      throw new Error(`CSV file not found. Please upload the file first.`)
    }

    const fileContent = fs.readFileSync(csvFilePath, { encoding: "utf-8" })
    const records = parse(fileContent, {
      columns: true,
      skip_empty_lines: true,
    })

    // Add special product - Amazon Echo Dot
    const echoDotImageUrl =
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/Amazon-Echo-Dot-5th-Generation-Without-Clock-pDr4ZwczwJaz3InTD7nV6wUUeGSNhb.png"
    const echoDotImagePath = await saveImageToStorage(echoDotImageUrl, "amazon-echo-dot")

    // Add Echo Dot as first product
    await sql`
      INSERT INTO products (
        name,
        slug,
        description,
        price,
        compare_at_price,
        category_id,
        images,
        featured,
        is_new,
        is_on_sale,
        tags,
        inventory
      ) VALUES (
        ${"Amazon Echo Dot (5th Generation)"},
        ${"amazon-echo-dot-5th-generation"},
        ${"Smart speaker with improved sound and Alexa. Voice control your entertainment, get answers to your questions, and easily control your smart home."},
        ${9999},
        ${12999},
        ${1},
        ${JSON.stringify([echoDotImagePath])},
        ${true},
        ${true},
        ${true},
        ${JSON.stringify(["Smart Home", "Speaker", "Alexa"])},
        ${50}
      )
    `

    // Process products from CSV
    let processedCount = 0
    const totalProducts = Math.min(records.length, 20) // Limit to 20 products for demo

    for (let i = 0; i < totalProducts; i++) {
      const record = records[i]

      // Skip if no title or price
      if (!record.Title || !record["Variant Price"]) {
        continue
      }

      let imagePath = null

      // Save image if available
      if (record["Image Src"]) {
        imagePath = await saveImageToStorage(record["Image Src"], record.Handle)
      }

      // Generate slug from title
      const slug =
        record.Handle ||
        record.Title.toLowerCase()
          .replace(/\s+/g, "-")
          .replace(/[^a-z0-9-]/g, "")

      // Parse prices
      const price = Math.round(Number.parseFloat(record["Variant Price"]) * 100) // Convert to cents
      const compareAtPrice = record["Variant Compare At Price"]
        ? Math.round(Number.parseFloat(record["Variant Compare At Price"]) * 100)
        : null

      // Parse tags
      const tags = record.Tags ? record.Tags.split(",").map((tag: string) => tag.trim()) : []

      // Determine category ID (simplified)
      const categoryId = Math.floor(Math.random() * 5) + 1

      // Insert product
      await sql`
        INSERT INTO products (
          name,
          slug,
          description,
          price,
          compare_at_price,
          category_id,
          images,
          featured,
          is_new,
          is_on_sale,
          tags,
          inventory
        ) VALUES (
          ${record.Title},
          ${slug},
          ${record["Body (HTML)"] || `Description for ${record.Title}`},
          ${price},
          ${compareAtPrice},
          ${categoryId},
          ${JSON.stringify(imagePath ? [imagePath] : [])},
          ${Math.random() > 0.7}, /* 30% chance of being featured */
          ${Math.random() > 0.6}, /* 40% chance of being new */
          ${compareAtPrice !== null}, /* On sale if compare price exists */
          ${JSON.stringify(tags)},
          ${Math.floor(Math.random() * 100) + 1}
        )
      `

      processedCount++
    }

    return NextResponse.json({
      success: true,
      count: processedCount + 1, // Including Echo Dot
      message: "Products imported successfully",
    })
  } catch (error: any) {
    console.error("Error importing products:", error)
    return NextResponse.json({ error: error.message || "Failed to import products" }, { status: 500 })
  }
}

