import { NextResponse } from "next/server"
import setupDatabase from "@/scripts/setup-database"

export async function POST() {
  try {
    const result = await setupDatabase()

    if (result.success) {
      return NextResponse.json({ success: true, message: "Database setup completed successfully" })
    } else {
      return NextResponse.json(
        { success: false, error: result.error?.message || "Database setup failed" },
        { status: 500 },
      )
    }
  } catch (error: any) {
    console.error("Error setting up database:", error)
    return NextResponse.json(
      { success: false, error: error.message || "An unexpected error occurred" },
      { status: 500 },
    )
  }
}

