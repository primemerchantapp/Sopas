import { NextResponse } from "next/server"
import fs from "fs"
import path from "path"
import fetch from "node-fetch"

export async function POST() {
  try {
    // Create data directory if it doesn't exist
    const dataDir = path.resolve(process.cwd(), "data")
    if (!fs.existsSync(dataDir)) {
      fs.mkdirSync(dataDir, { recursive: true })
    }

    // URL of the CSV file
    const csvUrl =
      "https://hebbkx1anhila5yf.public.blob.vercel-storage.com/products_export%20%281%29%20%281%29-nmoS2970yNIo8EJ8Ph35IXkdisHX4E.csv"

    // Output path
    const outputPath = path.resolve(dataDir, "products_export.csv")

    // Download the file
    const response = await fetch(csvUrl)

    if (!response.ok) {
      throw new Error(`Failed to download: ${response.status} ${response.statusText}`)
    }

    // Write to file
    const buffer = await response.buffer()
    fs.writeFileSync(outputPath, buffer)

    return NextResponse.json({ success: true, message: "CSV downloaded successfully" })
  } catch (error: any) {
    console.error("Error downloading CSV:", error)
    return NextResponse.json({ error: error.message || "Failed to download CSV" }, { status: 500 })
  }
}

