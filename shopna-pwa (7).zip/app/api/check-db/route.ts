import { NextResponse } from "next/server"
import { checkDatabaseConnection } from "@/lib/db"

export async function GET() {
  const result = await checkDatabaseConnection()

  if (result.connected) {
    return NextResponse.json({ status: "connected" })
  } else {
    return NextResponse.json(
      {
        status: "disconnected",
        error: result.error || "Could not connect to database",
      },
      { status: 500 },
    )
  }
}

