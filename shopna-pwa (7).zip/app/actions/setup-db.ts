"use server"

import { migrate } from "@/lib/migrate"
import { seedDatabase } from "@/lib/seed"

export async function setupDatabase() {
  try {
    await migrate()
    await seedDatabase()
    return { success: true, message: "Database setup completed successfully" }
  } catch (error) {
    console.error("Error setting up database:", error)
    return {
      success: false,
      message: "Error setting up database",
      error: error instanceof Error ? error.message : String(error),
    }
  }
}

