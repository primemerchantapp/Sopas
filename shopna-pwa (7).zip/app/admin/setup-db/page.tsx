"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { setupDatabase } from "@/app/actions/setup-db"
import { Loader2 } from "lucide-react"

export default function SetupDatabasePage() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<{ success: boolean; message: string; error?: string } | null>(null)

  const handleSetupDatabase = async () => {
    setIsLoading(true)
    try {
      const result = await setupDatabase()
      setResult(result)
    } catch (error) {
      setResult({
        success: false,
        message: "Error setting up database",
        error: error instanceof Error ? error.message : String(error),
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-md mx-auto">
        <CardHeader>
          <CardTitle>Database Setup</CardTitle>
          <CardDescription>Set up the database schema and seed initial data</CardDescription>
        </CardHeader>
        <CardContent>
          <p className="text-sm text-gray-500 mb-4">
            This will create all necessary tables and populate them with sample data. If the tables already exist, it
            will only add data if they are empty.
          </p>

          {result && (
            <div
              className={`p-4 rounded-md mt-4 ${result.success ? "bg-green-50 text-green-800" : "bg-red-50 text-red-800"}`}
            >
              <p className="font-medium">{result.message}</p>
              {result.error && <p className="text-sm mt-2">{result.error}</p>}
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={handleSetupDatabase} disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Setting up database...
              </>
            ) : (
              "Set Up Database"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

