"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, AlertCircle, Database, Loader2 } from "lucide-react"

export default function SetupPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [result, setResult] = useState<{ success?: boolean; message?: string; error?: string } | null>(null)
  const [logs, setLogs] = useState<string[]>([])

  const setupDatabase = async () => {
    try {
      setIsLoading(true)
      setResult(null)
      setLogs(["Starting database setup..."])

      const response = await fetch("/api/admin/setup-database", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
      })

      const data = await response.json()

      if (response.ok) {
        setResult({ success: true, message: data.message })
        setLogs((prev) => [
          ...prev,
          "Database schema created successfully",
          "Database seeded successfully",
          "Setup completed!",
        ])
      } else {
        setResult({ success: false, error: data.error || "Failed to set up database" })
        setLogs((prev) => [...prev, `Error: ${data.error || "Unknown error"}`])
      }
    } catch (error: any) {
      setResult({ success: false, error: error.message || "An unexpected error occurred" })
      setLogs((prev) => [...prev, `Error: ${error.message || "Unknown error"}`])
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <div className="container max-w-3xl py-10">
      <Card>
        <CardHeader>
          <CardTitle className="text-2xl flex items-center gap-2">
            <Database className="h-6 w-6" />
            Database Setup
          </CardTitle>
          <CardDescription>Set up the SoPas database with tables and initial data</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          {result?.success && (
            <Alert className="bg-green-50 border-green-200 text-green-800">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle>Success</AlertTitle>
              <AlertDescription>{result.message}</AlertDescription>
            </Alert>
          )}

          {result?.error && (
            <Alert className="bg-red-50 border-red-200 text-red-800">
              <AlertCircle className="h-4 w-4 text-red-600" />
              <AlertTitle>Error</AlertTitle>
              <AlertDescription>{result.error}</AlertDescription>
            </Alert>
          )}

          <div className="bg-gray-50 p-4 rounded-md border">
            <h3 className="font-medium mb-2">Setup Logs</h3>
            <div className="bg-black text-green-400 p-3 rounded font-mono text-sm h-60 overflow-y-auto">
              {logs.length === 0 ? (
                <p className="text-gray-500">Logs will appear here during setup...</p>
              ) : (
                logs.map((log, index) => (
                  <div key={index} className="mb-1">
                    <span className="text-gray-400">{">"}</span> {log}
                  </div>
                ))
              )}
            </div>
          </div>
        </CardContent>
        <CardFooter>
          <Button onClick={setupDatabase} disabled={isLoading} className="w-full">
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Setting Up Database...
              </>
            ) : (
              "Set Up Database"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

