"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, CheckCircle } from "lucide-react"

export default function ImportProductsPage() {
  const [loading, setLoading] = useState(false)
  const [completed, setCompleted] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [logs, setLogs] = useState<string[]>([])

  const importProducts = async () => {
    try {
      setLoading(true)
      setError(null)
      setLogs(["Starting product import process..."])

      // Step 1: Download CSV
      setLogs((prev) => [...prev, "Downloading CSV file..."])
      const downloadRes = await fetch("/api/admin/download-csv", { method: "POST" })
      if (!downloadRes.ok) {
        throw new Error("Failed to download CSV file")
      }
      setLogs((prev) => [...prev, "CSV file downloaded successfully"])

      // Step 2: Import products
      setLogs((prev) => [...prev, "Importing products into database..."])
      const importRes = await fetch("/api/admin/import-products", { method: "POST" })
      if (!importRes.ok) {
        throw new Error("Failed to import products")
      }

      const result = await importRes.json()
      setLogs((prev) => [...prev, `Imported ${result.count} products successfully`])

      setCompleted(true)
      setLogs((prev) => [...prev, "Import process completed!"])
    } catch (err) {
      console.error("Import error:", err)
      setError(err instanceof Error ? err.message : "An unknown error occurred")
      setLogs((prev) => [...prev, `Error: ${err instanceof Error ? err.message : "Unknown error"}`])
    } finally {
      setLoading(false)
    }
  }

  return (
    <div className="container mx-auto py-10">
      <Card className="max-w-2xl mx-auto">
        <CardHeader>
          <CardTitle>Import Products</CardTitle>
          <CardDescription>
            Import products from the provided CSV file and Amazon Echo Dot image into your database.
          </CardDescription>
        </CardHeader>
        <CardContent>
          <p className="mb-4">This process will:</p>
          <ul className="list-disc pl-6 space-y-2 mb-6">
            <li>Download the product CSV file</li>
            <li>Import the Amazon Echo Dot product with image</li>
            <li>Import additional products from the CSV file</li>
            <li>Store all images in the database</li>
          </ul>

          {logs.length > 0 && (
            <div className="mt-4 p-4 bg-black/5 dark:bg-white/5 rounded-md">
              <h3 className="font-medium mb-2">Process Log:</h3>
              <div className="space-y-1 font-mono text-sm max-h-60 overflow-y-auto">
                {logs.map((log, i) => (
                  <div key={i} className="border-l-2 border-primary pl-2">
                    {log}
                  </div>
                ))}
              </div>
            </div>
          )}

          {error && (
            <div className="mt-4 p-4 bg-red-100 dark:bg-red-900/20 text-red-700 dark:text-red-300 rounded-md">
              {error}
            </div>
          )}
        </CardContent>
        <CardFooter className="flex justify-between">
          <Button onClick={importProducts} disabled={loading || completed} className="w-full">
            {loading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Importing Products...
              </>
            ) : completed ? (
              <>
                <CheckCircle className="mr-2 h-4 w-4" />
                Import Completed
              </>
            ) : (
              "Start Import"
            )}
          </Button>
        </CardFooter>
      </Card>
    </div>
  )
}

