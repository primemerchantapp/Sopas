import type React from "react"
import { AdminNav } from "@/components/admin-nav"

export default function AdminLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <div className="flex min-h-screen">
      <div className="w-64 border-r bg-white p-4">
        <div className="mb-8">
          <h1 className="text-xl font-bold">SoPas Admin</h1>
          <p className="text-sm text-gray-500">Manage your store</p>
        </div>
        <AdminNav />
      </div>
      <div className="flex-1 overflow-auto">
        <main>{children}</main>
      </div>
    </div>
  )
}

