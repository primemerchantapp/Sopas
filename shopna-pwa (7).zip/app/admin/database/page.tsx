"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { CheckCircle, XCircle, AlertCircle, Database } from "lucide-react"
// Import the DatabaseSetupGuide component
import { DatabaseSetupGuide } from "@/components/database-setup-guide"

export default function DatabasePage() {
  const [status, setStatus] = useState<"loading" | "connected" | "error">("loading")
  const [message, setMessage] = useState<string>("")

  const checkConnection = async () => {
    setStatus("loading")
    try {
      const response = await fetch("/api/check-db")
      const data = await response.json()

      if (data.status === "connected") {
        setStatus("connected")
      } else {
        setStatus("error")
        setMessage(data.message || "Could not connect to database")
      }
    } catch (error) {
      setStatus("error")
      setMessage(error instanceof Error ? error.message : "Unknown error occurred")
    }
  }

  useEffect(() => {
    checkConnection()
  }, [])

  return (
    <div className="container mx-auto py-10">
      <h1 className="text-3xl font-bold mb-6">Database Connection</h1>

      <Card className="mb-6">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Database className="h-5 w-5" />
            Database Status
          </CardTitle>
          <CardDescription>Check the connection to your Neon PostgreSQL database</CardDescription>
        </CardHeader>
        <CardContent>
          {status === "loading" && (
            <Alert>
              <AlertCircle className="h-4 w-4" />
              <AlertTitle>Checking connection...</AlertTitle>
              <AlertDescription>Attempting to connect to your database...</AlertDescription>
            </Alert>
          )}

          {status === "connected" && (
            <Alert className="bg-green-50 border-green-200">
              <CheckCircle className="h-4 w-4 text-green-600" />
              <AlertTitle className="text-green-800">Connected</AlertTitle>
              <AlertDescription className="text-green-700">
                Successfully connected to your Neon PostgreSQL database.
              </AlertDescription>
            </Alert>
          )}

          {status === "error" && (
            <Alert className="bg-red-50 border-red-200">
              <XCircle className="h-4 w-4 text-red-600" />
              <AlertTitle className="text-red-800">Connection Error</AlertTitle>
              <AlertDescription className="text-red-700">
                {message || "Could not connect to the database. Please check your DATABASE_URL environment variable."}
              </AlertDescription>
            </Alert>
          )}
        </CardContent>
        <CardFooter>
          <Button onClick={checkConnection} disabled={status === "loading"}>
            {status === "loading" ? "Checking..." : "Check Connection"}
          </Button>
        </CardFooter>
      </Card>

      <DatabaseSetupGuide />

      <Card>
        <CardHeader>
          <CardTitle>Database Setup Instructions</CardTitle>
          <CardDescription>Follow these steps to set up your database connection</CardDescription>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-medium">1. Create a Neon PostgreSQL Database</h3>
            <p className="text-sm text-gray-500">
              If you haven't already, create a Neon PostgreSQL database from your Vercel dashboard or directly from
              Neon.
            </p>
          </div>

          <div>
            <h3 className="font-medium">2. Add the DATABASE_URL Environment Variable</h3>
            <p className="text-sm text-gray-500">
              Add your Neon connection string as the DATABASE_URL environment variable in your Vercel project settings.
            </p>
          </div>

          <div>
            <h3 className="font-medium">3. Redeploy Your Application</h3>
            <p className="text-sm text-gray-500">
              After adding the environment variable, redeploy your application for the changes to take effect.
            </p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

