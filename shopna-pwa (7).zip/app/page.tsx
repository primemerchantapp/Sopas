import { Suspense } from "react"
import { FeaturedProducts } from "@/components/featured-products"
import { Categories } from "@/components/categories"
import { Hero } from "@/components/hero-section"
import { NewArrivals } from "@/components/new-arrivals"
import { Testimonials } from "@/components/testimonials"
import { Newsletter } from "@/components/newsletter"
import { Skeleton } from "@/components/ui/skeleton"

export default function Home() {
  return (
    <div className="container px-4 md:px-6 py-6 space-y-10">
      <Hero
        title="Welcome to SoPas"
        subtitle="Your one-stop shop for all your needs"
        ctaText="Shop Now"
        ctaLink="/shop"
      />
      <Suspense
        fallback={
          <div className="h-48">
            <Skeleton className="h-full w-full" />
          </div>
        }
      >
        <Categories />
      </Suspense>
      <Suspense
        fallback={
          <div className="h-96">
            <Skeleton className="h-full w-full" />
          </div>
        }
      >
        <FeaturedProducts />
      </Suspense>
      <Suspense
        fallback={
          <div className="h-96">
            <Skeleton className="h-full w-full" />
          </div>
        }
      >
        <NewArrivals />
      </Suspense>
      <Testimonials />
      <Newsletter />
    </div>
  )
}

