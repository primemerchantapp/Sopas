export interface Product {
  id: string
  name: string
  price: number
  originalPrice?: number
  image: string
  images?: string[]
  description: string
  category: string
  isNew?: boolean
  isOnSale?: boolean
  featured?: boolean
  stock: number
  sku: string
  tags?: string[]
  rating?: number
  reviewCount?: number
}

