import Link from "next/link"
import { Database, Package, Settings, ShoppingBag, Users } from "lucide-react"

export function AdminNav() {
  return (
    <nav className="flex flex-col space-y-1">
      <Link
        href="/admin/dashboard"
        className="flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-100"
      >
        <ShoppingBag className="mr-3 h-5 w-5" />
        Dashboard
      </Link>
      <Link
        href="/admin/products"
        className="flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-100"
      >
        <Package className="mr-3 h-5 w-5" />
        Products
      </Link>
      <Link
        href="/admin/users"
        className="flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-100"
      >
        <Users className="mr-3 h-5 w-5" />
        Users
      </Link>
      <Link
        href="/admin/setup"
        className="flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-100"
      >
        <Database className="mr-3 h-5 w-5" />
        Database Setup
      </Link>
      <Link
        href="/admin/settings"
        className="flex items-center px-4 py-2 text-sm font-medium rounded-md hover:bg-gray-100"
      >
        <Settings className="mr-3 h-5 w-5" />
        Settings
      </Link>
    </nav>
  )
}

