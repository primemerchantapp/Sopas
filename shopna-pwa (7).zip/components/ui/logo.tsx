"use client"

import { useTheme } from "next-themes"
import Image from "next/image"
import Link from "next/link"
import { useEffect, useState } from "react"

interface LogoProps {
  className?: string
  width?: number
  height?: number
}

export function Logo({ className = "", width = 150, height = 112 }: LogoProps) {
  const { resolvedTheme } = useTheme()
  const [logoSrc, setLogoSrc] = useState("/images/logo-dark.svg")

  // Wait for theme to be resolved to avoid hydration mismatch
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  useEffect(() => {
    if (mounted) {
      setLogoSrc(resolvedTheme === "dark" ? "/images/logo-light.svg" : "/images/logo-dark.svg")
    }
  }, [resolvedTheme, mounted])

  return (
    <Link href="/" className={`block ${className}`}>
      <Image
        src={logoSrc || "/placeholder.svg"}
        alt="SoPas Logo"
        width={width}
        height={height}
        className="transition-opacity duration-300"
        priority
      />
    </Link>
  )
}

