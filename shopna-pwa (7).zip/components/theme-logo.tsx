"use client"

import { useTheme } from "next-themes"
import Image from "next/image"
import { useEffect, useState } from "react"

interface ThemeLogoProps {
  className?: string
  width?: number
  height?: number
}

export function ThemeLogo({ className = "", width = 120, height = 90 }: ThemeLogoProps) {
  const { theme, resolvedTheme } = useTheme()
  const [logoSrc, setLogoSrc] = useState("/logo-light.svg")

  useEffect(() => {
    // Default to light logo, then switch based on theme
    const isDark = theme === "dark" || resolvedTheme === "dark"
    setLogoSrc(isDark ? "/logo-light.svg" : "/logo-dark.svg")
  }, [theme, resolvedTheme])

  return (
    <div className={className}>
      <Image src={logoSrc || "/placeholder.svg"} alt="SoPas Logo" width={width} height={height} priority />
    </div>
  )
}

