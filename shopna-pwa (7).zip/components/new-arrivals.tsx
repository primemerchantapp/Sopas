import Link from "next/link"
import Image from "next/image"
import { getNewArrivals } from "@/lib/db-operations"
import { AddToCartButton } from "@/components/add-to-cart-button"
import { formatCurrency } from "@/lib/utils"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"

export async function NewArrivals() {
  const products = await getNewArrivals(8)

  return (
    <section className="w-full py-12">
      <div className="flex flex-col items-center justify-between gap-4 md:flex-row">
        <div className="space-y-1">
          <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl">New Arrivals</h2>
          <p className="text-gray-500 dark:text-gray-400">Check out our latest products</p>
        </div>
        <div className="flex justify-end">
          <Link href="/shop">
            <Button variant="outline">View All</Button>
          </Link>
        </div>
      </div>
      <div className="grid grid-cols-1 gap-6 sm:grid-cols-2 lg:grid-cols-4 mt-8">
        {products && products.length > 0 ? (
          products.map((product) => (
            <Card key={product.id} className="overflow-hidden group">
              <Link href={`/product/${product.slug}`}>
                <div className="aspect-square relative overflow-hidden">
                  <Image
                    src={product.image_url || "/placeholder.svg?height=400&width=400"}
                    alt={product.name}
                    fill
                    className="object-cover transition-transform group-hover:scale-105"
                  />
                </div>
              </Link>
              <CardContent className="p-4">
                <Link href={`/product/${product.slug}`} className="hover:underline">
                  <h3 className="font-medium text-lg truncate">{product.name}</h3>
                </Link>
                <p className="text-sm text-gray-500 dark:text-gray-400 line-clamp-2 h-10">{product.description}</p>
              </CardContent>
              <CardFooter className="p-4 pt-0 flex items-center justify-between">
                <div className="font-bold">{formatCurrency(product.price)}</div>
                <AddToCartButton product={product} variant="secondary" />
              </CardFooter>
            </Card>
          ))
        ) : (
          <div className="col-span-full text-center py-12">
            <p className="text-gray-500 dark:text-gray-400">No new products available</p>
          </div>
        )}
      </div>
    </section>
  )
}

