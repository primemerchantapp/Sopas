"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { ShoppingCart } from "lucide-react"
import { useCart } from "@/context/cart-context"
import type { Product } from "@/types"
import { toast } from "@/hooks/use-toast"

interface AddToCartButtonProps {
  product: Product
  variant?: "default" | "secondary" | "outline"
  size?: "default" | "sm" | "lg" | "icon"
  quantity?: number
  className?: string
}

export function AddToCartButton({
  product,
  variant = "default",
  size = "default",
  quantity = 1,
  className = "",
}: AddToCartButtonProps) {
  const { addToCart } = useCart()
  const [isAdding, setIsAdding] = useState(false)

  const handleAddToCart = () => {
    setIsAdding(true)

    setTimeout(() => {
      addToCart(product, quantity)
      setIsAdding(false)

      toast({
        title: "Added to cart",
        description: `${product.name} has been added to your cart`,
      })
    }, 500)
  }

  return (
    <Button variant={variant} size={size} onClick={handleAddToCart} disabled={isAdding} className={className}>
      <ShoppingCart className="h-4 w-4 mr-2" />
      {size !== "icon" && "Add to Cart"}
    </Button>
  )
}

