"use client"

import Link from "next/link"
import { useState, useEffect } from "react"
import { ShoppingCart, User, Search, Phone, Mail } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { SideNavbar } from "@/components/side-navbar"

export function TopNavbar() {
  const [showContactInfo, setShowContactInfo] = useState(true)
  const [prevScrollPos, setPrevScrollPos] = useState(0)

  useEffect(() => {
    const handleScroll = () => {
      const currentScrollPos = window.scrollY

      if (currentScrollPos > 100) {
        setShowContactInfo(false)
      } else {
        setShowContactInfo(true)
      }

      setPrevScrollPos(currentScrollPos)
    }

    window.addEventListener("scroll", handleScroll)
    return () => window.removeEventListener("scroll", handleScroll)
  }, [prevScrollPos])

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      {showContactInfo && (
        <div className="hidden md:flex items-center justify-between px-4 py-2 bg-muted/50">
          <div className="flex items-center space-x-4">
            <div className="flex items-center space-x-1">
              <Phone className="h-3 w-3" />
              <span className="text-xs">+63 912 345 6789</span>
            </div>
            <div className="flex items-center space-x-1">
              <Mail className="h-3 w-3" />
              <span className="text-xs">support@shapna.com</span>
            </div>
          </div>
          <div className="text-xs">Free shipping for orders over ₱1000</div>
        </div>
      )}

      <div className="container flex h-16 items-center">
        <div className="flex items-center">
          <SideNavbar />
          <Link href="/" className="font-bold text-xl ml-2">
            ShapNa
          </Link>
        </div>

        <div className="flex items-center ml-auto">
          <div className="relative hidden md:flex items-center mr-4 w-full max-w-sm">
            <Search className="absolute left-2.5 h-4 w-4 text-muted-foreground" />
            <Input type="search" placeholder="Search products..." className="w-full pl-8 md:w-[300px] lg:w-[400px]" />
          </div>

          <nav className="flex items-center space-x-2">
            <Link href="/cart">
              <Button variant="ghost" size="icon">
                <ShoppingCart className="h-5 w-5" />
                <span className="sr-only">Cart</span>
              </Button>
            </Link>
            <Link href="/account">
              <Button variant="ghost" size="icon">
                <User className="h-5 w-5" />
                <span className="sr-only">Account</span>
              </Button>
            </Link>
          </nav>
        </div>
      </div>
    </header>
  )
}

