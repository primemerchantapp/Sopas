"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle2 } from "lucide-react"

export function DatabaseSetupGuide() {
  const [checking, setChecking] = useState(false)
  const [status, setStatus] = useState<null | { connected: boolean; error?: string }>(null)

  const checkConnection = async () => {
    setChecking(true)
    try {
      const response = await fetch("/api/check-db")
      const data = await response.json()

      if (data.status === "connected") {
        setStatus({ connected: true })
      } else {
        setStatus({ connected: false, error: data.error })
      }
    } catch (error) {
      setStatus({
        connected: false,
        error: error instanceof Error ? error.message : "Failed to check database connection",
      })
    } finally {
      setChecking(false)
    }
  }

  return (
    <Card className="w-full max-w-md mx-auto">
      <CardHeader>
        <CardTitle>Database Connection</CardTitle>
        <CardDescription>Check and configure your Neon database connection</CardDescription>
      </CardHeader>
      <CardContent className="space-y-4">
        {status && (
          <Alert variant={status.connected ? "default" : "destructive"}>
            {status.connected ? <CheckCircle2 className="h-4 w-4" /> : <AlertCircle className="h-4 w-4" />}
            <AlertTitle>{status.connected ? "Connected" : "Connection Failed"}</AlertTitle>
            <AlertDescription>
              {status.connected
                ? "Successfully connected to your Neon database."
                : `Error: ${status.error || "Unknown error"}`}
            </AlertDescription>
          </Alert>
        )}

        <div className="text-sm space-y-2">
          <p>Make sure you have:</p>
          <ol className="list-decimal list-inside space-y-1">
            <li>Added the Neon integration to your project</li>
            <li>Set the DATABASE_URL environment variable</li>
            <li>Redeployed your application after setting the environment variable</li>
          </ol>
        </div>
      </CardContent>
      <CardFooter>
        <Button onClick={checkConnection} disabled={checking}>
          {checking ? "Checking..." : "Check Connection"}
        </Button>
      </CardFooter>
    </Card>
  )
}

