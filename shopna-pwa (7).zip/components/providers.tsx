"use client"

import type React from "react"
import { AuthProvider } from "@/context/auth-context"
import { CartProvider } from "@/context/cart-context"
import { RegisterSW } from "@/app/register-sw"
import { ImagePreloader } from "@/components/image-preloader"
import { useEffect } from "react"
import { initializeLocalStorage } from "@/lib/db-operations"

export function Providers({ children }: { children: React.ReactNode }) {
  // Initialize local storage with sample data
  useEffect(() => {
    try {
      initializeLocalStorage()
    } catch (e) {
      console.error("Error initializing local storage:", e)
    }
  }, [])

  return (
    <AuthProvider>
      <CartProvider>
        {children}
        <RegisterSW />
        <ImagePreloader />
      </CartProvider>
    </AuthProvider>
  )
}

