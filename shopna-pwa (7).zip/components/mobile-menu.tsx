import { Sheet, SheetContent, SheetHeader, SheetTrigger } from "@/components/ui/sheet"
import { Menu } from "lucide-react"
import { Button } from "@/components/ui/button"
import { ModeToggle } from "@/components/mode-toggle"
import { MainNav } from "@/components/main-nav"
import { Logo } from "@/components/ui/logo"

export function MobileMenu() {
  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon">
          <Menu className="h-4 w-4" />
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-full sm:w-64">
        <SheetHeader>
          <Logo className="mx-auto mb-6" />
        </SheetHeader>
        <MainNav className="flex flex-col gap-4" />
        <div className="flex flex-col gap-4 pt-6">
          <ModeToggle />
        </div>
      </SheetContent>
    </Sheet>
  )
}

