"use client"

import { useTheme } from "next-themes"

interface LogoProps {
  className?: string
  width?: number
  height?: number
}

export function Logo({ className, width = 120, height = 120 }: LogoProps) {
  const { resolvedTheme } = useTheme()
  const isDark = resolvedTheme === "dark"

  return (
    <div className={className} style={{ width, height }}>
      {isDark ? (
        // Light version for dark theme
        <svg width={width} height={height} viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg">
          {/* Circle */}
          <circle cx="250" cy="250" r="200" fill="none" stroke="#4ade80" strokeWidth="30" />

          {/* Cart */}
          <g fill="#ffffff">
            {/* Cart body */}
            <path d="M150,180 L350,180 L330,300 L170,300 Z" strokeWidth="15" stroke="#ffffff" fill="none" />

            {/* Cart handle */}
            <path d="M350,180 L390,120" strokeWidth="15" stroke="#ffffff" fill="none" />

            {/* Items in cart */}
            <rect x="170" y="210" width="160" height="15" rx="5" />
            <rect x="170" y="240" width="160" height="15" rx="5" />
            <rect x="170" y="270" width="160" height="15" rx="5" />

            {/* Wheels */}
            <circle cx="200" cy="340" r="25" />
            <circle cx="300" cy="340" r="25" />

            {/* Connection between wheels */}
            <rect x="200" y="335" width="100" height="10" />
          </g>

          {/* Dots */}
          <g fill="#ffffff">
            <rect x="380" y="180" width="15" height="15" rx="3" />
            <rect x="380" y="210" width="15" height="15" rx="3" />
            <rect x="380" y="240" width="15" height="15" rx="3" />
            <rect x="410" y="180" width="15" height="15" rx="3" />
            <rect x="410" y="210" width="15" height="15" rx="3" />
            <rect x="410" y="240" width="15" height="15" rx="3" />
            <rect x="440" y="180" width="15" height="15" rx="3" />
            <rect x="440" y="210" width="15" height="15" rx="3" />
            <rect x="440" y="240" width="15" height="15" rx="3" />
          </g>
        </svg>
      ) : (
        // Dark version for light theme
        <svg width={width} height={height} viewBox="0 0 500 500" xmlns="http://www.w3.org/2000/svg">
          {/* Circle */}
          <circle cx="250" cy="250" r="200" fill="none" stroke="#4ade80" strokeWidth="30" />

          {/* Cart */}
          <g fill="#1e293b">
            {/* Cart body */}
            <path d="M150,180 L350,180 L330,300 L170,300 Z" strokeWidth="15" stroke="#1e293b" fill="none" />

            {/* Cart handle */}
            <path d="M350,180 L390,120" strokeWidth="15" stroke="#1e293b" fill="none" />

            {/* Items in cart */}
            <rect x="170" y="210" width="160" height="15" rx="5" />
            <rect x="170" y="240" width="160" height="15" rx="5" />
            <rect x="170" y="270" width="160" height="15" rx="5" />

            {/* Wheels */}
            <circle cx="200" cy="340" r="25" />
            <circle cx="300" cy="340" r="25" />

            {/* Connection between wheels */}
            <rect x="200" y="335" width="100" height="10" />
          </g>

          {/* Dots */}
          <g fill="#1e293b">
            <rect x="380" y="180" width="15" height="15" rx="3" />
            <rect x="380" y="210" width="15" height="15" rx="3" />
            <rect x="380" y="240" width="15" height="15" rx="3" />
            <rect x="410" y="180" width="15" height="15" rx="3" />
            <rect x="410" y="210" width="15" height="15" rx="3" />
            <rect x="410" y="240" width="15" height="15" rx="3" />
            <rect x="440" y="180" width="15" height="15" rx="3" />
            <rect x="440" y="210" width="15" height="15" rx="3" />
            <rect x="440" y="240" width="15" height="15" rx="3" />
          </g>
        </svg>
      )}
    </div>
  )
}

