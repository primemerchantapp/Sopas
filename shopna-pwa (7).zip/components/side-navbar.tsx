"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { Home, Search, ShoppingBag, Heart, User, Menu, X, ChevronRight } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetTrigger, SheetClose } from "@/components/ui/sheet"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { cn } from "@/lib/utils"

const navItems = [
  {
    name: "Home",
    href: "/",
    icon: Home,
  },
  {
    name: "Search",
    href: "/search",
    icon: Search,
  },
  {
    name: "Cart",
    href: "/cart",
    icon: ShoppingBag,
  },
  {
    name: "Wishlist",
    href: "/wishlist",
    icon: Heart,
  },
  {
    name: "Account",
    href: "/account",
    icon: User,
  },
]

const subscriptionPlans = [
  {
    name: "Free",
    price: "0.00",
    monthlyPrice: "0.00",
    features: ["Basic shop features", "Up to 10 products", "Standard support"],
  },
  {
    name: "Starter",
    price: "499.00",
    monthlyPrice: "99.00",
    features: ["All Free features", "Up to 100 products", "Priority support", "Custom domain"],
  },
  {
    name: "Pro",
    price: "1499.00",
    monthlyPrice: "349.00",
    features: [
      "All Starter features",
      "Unlimited products",
      "Premium support",
      "Advanced analytics",
      "Multiple admins",
    ],
  },
]

export function SideNavbar() {
  const pathname = usePathname()
  const [showSubscriptionPlans, setShowSubscriptionPlans] = useState(false)
  const [currentPlan, setCurrentPlan] = useState("Free")

  return (
    <Sheet>
      <SheetTrigger asChild>
        <Button variant="ghost" size="icon" className="md:flex hidden">
          <Menu className="h-5 w-5" />
          <span className="sr-only">Toggle menu</span>
        </Button>
      </SheetTrigger>
      <SheetContent side="left" className="w-[300px] sm:w-[350px] p-0">
        <div className="flex flex-col h-full">
          <div className="p-4 border-b">
            <h2 className="text-xl font-bold">ShapNa</h2>
          </div>

          <div className="flex-1 overflow-auto py-2">
            <nav className="grid gap-1 px-2">
              {navItems.map((item) => {
                const isActive = pathname === item.href
                return (
                  <SheetClose asChild key={item.href}>
                    <Link
                      href={item.href}
                      className={cn(
                        "flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all",
                        isActive ? "bg-accent text-accent-foreground" : "hover:bg-accent hover:text-accent-foreground",
                      )}
                    >
                      <item.icon className="h-5 w-5" />
                      {item.name}
                    </Link>
                  </SheetClose>
                )
              })}
            </nav>
          </div>

          <div className="mt-auto border-t p-4">
            {showSubscriptionPlans ? (
              <div className="space-y-4">
                <div className="flex items-center justify-between">
                  <h3 className="text-lg font-medium">Subscription Plans</h3>
                  <Button variant="ghost" size="sm" onClick={() => setShowSubscriptionPlans(false)}>
                    <X className="h-4 w-4" />
                  </Button>
                </div>

                <div className="space-y-3">
                  {subscriptionPlans.map((plan) => (
                    <Card
                      key={plan.name}
                      className={cn(
                        "cursor-pointer hover:border-primary",
                        currentPlan === plan.name ? "border-primary" : "",
                      )}
                      onClick={() => setCurrentPlan(plan.name)}
                    >
                      <CardHeader className="pb-2">
                        <CardTitle>{plan.name}</CardTitle>
                        <CardDescription>
                          {plan.name !== "Free" ? (
                            <>
                              ₱{plan.price} one-time setup
                              <br />₱{plan.monthlyPrice} monthly
                            </>
                          ) : (
                            "Always free"
                          )}
                        </CardDescription>
                      </CardHeader>
                      <CardContent className="pb-2">
                        <Accordion type="single" collapsible className="w-full">
                          <AccordionItem value="features">
                            <AccordionTrigger className="text-sm py-1">Features</AccordionTrigger>
                            <AccordionContent>
                              <ul className="text-sm space-y-1">
                                {plan.features.map((feature, index) => (
                                  <li key={index} className="flex items-center gap-2">
                                    <div className="h-1.5 w-1.5 rounded-full bg-primary" />
                                    {feature}
                                  </li>
                                ))}
                              </ul>
                            </AccordionContent>
                          </AccordionItem>
                        </Accordion>
                      </CardContent>
                      <CardFooter>
                        {currentPlan === plan.name ? (
                          <Button variant="outline" className="w-full" disabled>
                            Current Plan
                          </Button>
                        ) : (
                          <Button variant="default" className="w-full">
                            {plan.name === "Free" ? "Downgrade" : "Upgrade"}
                          </Button>
                        )}
                      </CardFooter>
                    </Card>
                  ))}
                </div>
              </div>
            ) : (
              <>
                <div className="flex items-center justify-between mb-4">
                  <div>
                    <p className="text-sm text-muted-foreground">Current Plan</p>
                    <p className="font-medium">{currentPlan}</p>
                  </div>
                  <ChevronRight className="h-4 w-4 text-muted-foreground" />
                </div>
                <Button className="w-full" onClick={() => setShowSubscriptionPlans(true)}>
                  Subscribe
                </Button>
              </>
            )}
          </div>
        </div>
      </SheetContent>
    </Sheet>
  )
}

